import { Outlet, Scripts, Meta, Links, ScrollRestoration } from "react-router";
import "./style.css";
import { ThemeProvider } from "../../app/context/ThemeContext";
import { AuthProvider } from "../../app/context/AuthContext";
import { CartProvider } from "../../app/context/CartContext";
import Header from "../../app/components/Header";

export default function App() {
  return (
    <html lang="en">
      <head>
        <meta charSet="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <Meta />
        <Links />
      </head>

      <body>
        <ThemeProvider>
          <AuthProvider>
            <CartProvider>
              <Header />
              <main className="container">
                <Outlet />
              </main>
              <footer className="footer">
                <p>&copy; {new Date().getFullYear()} AZI Cosmetics Store. All rights reserved.</p>
              </footer>
            </CartProvider>
          </AuthProvider>
        </ThemeProvider>

        <ScrollRestoration />
        <Scripts />
      </body>
    </html>
  );
}