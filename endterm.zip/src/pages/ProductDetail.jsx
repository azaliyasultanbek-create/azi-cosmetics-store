import { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router";
import { productsApi } from "../../app/services/api";
import { useCart } from "../../app/context/CartContext";
import Loader from "../../app/components/Loader";

import {
  getReviews,
  createReview,
  deleteReview,
  updateReview,
} from "../../app/services/reviewService";

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addItem } = useCart();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedImage, setSelectedImage] = useState(0);
  const [reviews, setReviews] = useState([]);
  const [text, setText] = useState("");
  const [loadingReviews, setLoadingReviews] = useState(true);
  useEffect(() => {
    let cancelled = false;

    async function loadProduct() {
      setLoading(true);
      setError(null);
      try {
        const data = await productsApi.getById(id);
        if (!cancelled) {
          setProduct(data);
          setSelectedImage(0);
        }
      } catch (err) {
        if (!cancelled) {
          setError(err.message || "Failed to load product");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    loadProduct();
    window.scrollTo(0, 0);

    return () => {
      cancelled = true;
    };
  }, [id]);


  useEffect(() => {
    fetchReviews();
  }, []);

  const fetchReviews = async () => {
    try {
      const data = await getReviews();
      setReviews(data.slice(0, 3));
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingReviews(false);
    }
  };
  const handleAddReview = async () => {
    if (!text) return;

    const newReview = await createReview({ body: text });
    setReviews((prev) => [newReview, ...prev]);
    setText("");
  };

  const handleDeleteReview = async (id) => {
    await deleteReview(id);
    setReviews((prev) => prev.filter((r) => r.id !== id));
  };

  const handleUpdateReview = async (id) => {
    const updated = await updateReview(id, { body: "Updated review" });
    setReviews((prev) =>
      prev.map((r) => (r.id === id ? updated : r))
    );
  };

  // UI states
  if (loading) return <Loader text="Loading product..." />;

  if (error) {
    return (
      <div className="error-container">
        <h2>Product not found</h2>
        <p>{error}</p>
        <button onClick={() => navigate("/catalog")}>
          Back to Catalog
        </button>
      </div>
    );
  }

  if (!product) return null;

  const discountPrice = product.discountPercentage
    ? (product.price * (1 - product.discountPercentage / 100)).toFixed(2)
    : null;

  const allImages = product.images?.length
    ? product.images
    : [product.thumbnail];

  return (
    <div className="product-detail-page">
      <Link to="/catalog" className="back-link">
        ← Back to Catalog
      </Link>

      <div className="product-detail-layout">
        {/* ГАЛЕРЕЯ */}
        <div className="product-detail-gallery">
          <div className="product-detail-main-image">
            <img
              src={allImages[selectedImage] || product.thumbnail}
              alt={product.title}
            />
          </div>

          {allImages.length > 1 && (
            <div className="product-detail-thumbnails">
              {allImages.map((img, index) => (
                <button
                  key={index}
                  className={`thumbnail-btn ${
                    index === selectedImage ? "active" : ""
                  }`}
                  onClick={() => setSelectedImage(index)}
                >
                  <img src={img} alt={`${product.title} ${index + 1}`} />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ИНФО */}
        <div className="product-detail-info">
          <h1>{product.title}</h1>

          {product.brand && (
            <p className="product-brand">{product.brand}</p>
          )}

          <p className="product-category">{product.category}</p>

          <div className="product-detail-pricing">
            {discountPrice ? (
              <>
                <span className="current-price">
                  ${discountPrice}
                </span>
                <span className="old-price">
                  ${product.price}
                </span>
              </>
            ) : (
              <span className="current-price">
                ${product.price}
              </span>
            )}
          </div>

          <p>{product.description}</p>

          <button
            className="add-to-cart-btn"
            onClick={() => {
              addItem(product);
              navigate("/cart");
            }}
          >
            Add to Cart
          </button>
        </div>
      </div>
      <div style={{ marginTop: "40px" }}>
        <h2>Reviews</h2>

        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Write a review"
        />
        <button onClick={handleAddReview}>Add</button>

        {loadingReviews ? (
          <p>Loading reviews...</p>
        ) : !reviews.length ? (
          <p>No reviews</p>
        ) : (
          reviews.map((r) => (
            <div key={r.id} style={{ border: "1px solid gray", margin: 10 }}>
              <p>{r.body}</p>

              <button onClick={() => handleDeleteReview(r.id)}>
                Delete
              </button>

              <button onClick={() => handleUpdateReview(r.id)}>
                Update
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
