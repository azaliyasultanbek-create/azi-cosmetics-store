import { useState } from "react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [status, setStatus] = useState(""); 
  const [errors, setErrors] = useState({});
  const validate = () => {
    const newErrors = {};
    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Invalid email format";
    }
    if (!formData.message.trim()) {
      newErrors.message = "Message is required";
    } else if (formData.message.trim().length < 10) {
      newErrors.message = "Message must be at least 10 characters";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!validate()) return;

    console.log("Form Submitted:", formData);
    setStatus("Thank you! Your message has been sent");
    setFormData({ name: "", email: "", message: "" });
    setErrors({});

    // Clear success message after 5 seconds
    setTimeout(() => setStatus(""), 5000);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    // Clear error on change
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: "" }));
    }
  };

  return (
    <main className="contact-page">
      <section className="contact-card">
        <h2>Contact Us</h2>
        <p className="contact-subtitle">
          Have a question? We'd love to hear from you.
        </p>

        <form onSubmit={handleSubmit} className="contact-form" noValidate>
          <div className="form-group">
            <label htmlFor="name">Name</label>
            <input
              id="name"
              name="name"
              type="text"
              placeholder="Your Name"
            value={formData.name}
              onChange={handleChange}
              className={errors.name ? "input-error" : ""}
          />
            {errors.name && <span className="field-error">{errors.name}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              id="email"
              name="email"
              type="email"
              placeholder="your@email.com"
              value={formData.email}
              onChange={handleChange}
              className={errors.email ? "input-error" : ""}
          />
            {errors.email && <span className="field-error">{errors.email}</span>}
          </div>

          <div className="form-group">
            <label htmlFor="message">Message</label>
            <textarea
              id="message"
              name="message"
              placeholder="Your message (min. 10 characters)"
              value={formData.message}
              onChange={handleChange}
              className={errors.message ? "input-error" : ""}
          />
            {errors.message && <span className="field-error">{errors.message}</span>}
          </div>
          <button type="submit" className="submit-btn">
            Send Message
          </button>
        </form>  

        {status && <div className="success-message">{status}</div>}
      </section>
    </main>
  );
}